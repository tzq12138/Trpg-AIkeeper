# 文档包 Manifest

| 文件 | 字节数 | 行数 |
|---|---:|---:|
| `00_使用说明与总索引.md` | 7668 | 219 |
| `01_P0_RELEASE_CHECKLIST.md` | 26416 | 445 |
| `02_P1_PLAYABLE_ALPHA_SPEC.md` | 16101 | 408 |
| `03_AI_KP_QUALITY_RUBRIC.md` | 10258 | 401 |
| `04_PLAYTEST_PROTOCOL.md` | 12017 | 482 |
| `05_GLASS_RAIN_PLAYER_JOURNEY.md` | 14891 | 569 |
| `06_P1_IMPLEMENTATION_BACKLOG.md` | 10822 | 484 |
| `07_仓库实物核验清单.md` | 6605 | 267 |
| `99_参考_AI_KEEPER_P0_纯AI模式_冻结决策与实施任务包_v1.1.md` | 57513 | 1849 |
| `AI_KEEPER_P0_P1_完整文档包.md` | 105330 | 3327 |
